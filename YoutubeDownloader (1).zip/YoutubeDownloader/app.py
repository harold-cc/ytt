import os
import logging
logging.basicConfig(level=logging.DEBUG)
import subprocess
import json
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session, send_file
from pytube import YouTube, Search
import pytube.exceptions
import re
import tempfile
import googleapiclient.discovery
import googleapiclient.errors
import requests

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")

# YouTube Data API setup
YOUTUBE_API_KEY = os.environ.get("YOUTUBE_API_KEY", "")
youtube_api = None

if YOUTUBE_API_KEY:
    youtube_api = googleapiclient.discovery.build(
        "youtube", "v3", developerKey=YOUTUBE_API_KEY
    )

def is_downloadable(video_url):
    """
    Check if a video is downloadable using yt-dlp for maximum reliability
    """
    try:
        # Use yt-dlp to check for available formats instead of pytube
        # This is much more reliable and will catch more available formats
        cmd = [
            'yt-dlp', 
            '--no-playlist',
            '--list-formats',
            '--no-check-certificate',  # Avoid certificate errors
            video_url
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            # Look for 720p format (format_id=22) in the output
            if '22' in result.stdout and '720p' in result.stdout:
                logging.info(f"Found 720p format for {video_url}")
                return True
                
            # If no 720p found, look for any other format
            if 'format code' in result.stdout:
                logging.info(f"Found downloadable formats for {video_url}")
                return True
                
        logging.warning(f"No downloadable streams found for {video_url}")
        return True  # Return True anyway to allow the app to attempt download with fallbacks
    except Exception as e:
        logging.error(f"Error checking if video is downloadable: {str(e)}")
        # Return True anyway to allow the download attempt
        # This helps with videos that might appear undownloadable at first
        return True

def get_video_info(video_id):
    """
    Get video information using YouTube Data API
    """
    if not youtube_api:
        # Fallback to a more reliable method than direct pytube attributes
        try:
            url = f"https://www.youtube.com/watch?v={video_id}"
            
            # First try using direct YouTube embed info through oEmbed
            import requests
            try:
                oembed_url = f"https://www.youtube.com/oembed?url={url}&format=json"
                response = requests.get(oembed_url)
                
                if response.status_code == 200:
                    data = response.json()
                    # Use high resolution thumbnail
                    thumbnail = f"https://img.youtube.com/vi/{video_id}/hqdefault.jpg"
                    
                    return {
                        "title": data.get("title", f"YouTube Video {video_id}"),
                        "channel_title": data.get("author_name", "YouTube Creator"),
                        "thumbnail": thumbnail,
                        "description": "Click below to download this video in your preferred format.",
                        "view_count": "N/A",
                        "video_id": video_id
                    }
            except Exception as oe:
                logging.warning(f"oEmbed failed, trying pytube: {str(oe)}")
            
            # If oEmbed fails, try pytube as fallback
            yt = YouTube(url)
            
            return {
                "title": yt.title if hasattr(yt, 'title') and yt.title else f"YouTube Video {video_id}",
                "channel_title": yt.author if hasattr(yt, 'author') and yt.author else "YouTube Creator",
                "thumbnail": f"https://img.youtube.com/vi/{video_id}/hqdefault.jpg",
                "description": yt.description[:200] + "..." if hasattr(yt, 'description') and yt.description and len(yt.description) > 200 else "Click below to download this video in your preferred format.",
                "view_count": yt.views if hasattr(yt, 'views') else "N/A",
                "video_id": video_id
            }
        except Exception as e:
            logging.error(f"Error getting video info with pytube: {str(e)}")
            
            # Provide basic information even if there's an error
            return {
                "title": f"YouTube Video {video_id}",
                "channel_title": "YouTube Creator",
                "thumbnail": f"https://img.youtube.com/vi/{video_id}/hqdefault.jpg",
                "description": "Video information could not be retrieved. You can still try to download this video.",
                "view_count": "N/A",
                "video_id": video_id
            }
    
    try:
        request = youtube_api.videos().list(
            part="snippet,statistics",
            id=video_id
        )
        response = request.execute()
        
        if not response["items"]:
            return None
        
        video = response["items"][0]
        
        return {
            "title": video["snippet"]["title"],
            "channel_title": video["snippet"]["channelTitle"],
            "thumbnail": video["snippet"]["thumbnails"]["high"]["url"],
            "description": video["snippet"]["description"][:200] + "..." if len(video["snippet"]["description"]) > 200 else video["snippet"]["description"],
            "view_count": video["statistics"].get("viewCount", "N/A"),
            "video_id": video_id
        }
    except Exception as e:
        logging.error(f"Error getting video info with API: {str(e)}")
        return None

def search_videos(query, max_results=10):
    """
    Search for YouTube videos
    """
    if not youtube_api:
        # Fallback to pytube if API key is not available
        try:
            s = Search(query)
            results = []
            
            for i, result in enumerate(s.results):
                if i >= max_results:
                    break
                    
                results.append({
                    "title": result.title,
                    "channel_title": result.author,
                    "thumbnail": result.thumbnail_url,
                    "video_id": result.video_id
                })
                
            return results
        except Exception as e:
            logging.error(f"Error searching videos with pytube: {str(e)}")
            return []
    
    try:
        request = youtube_api.search().list(
            part="snippet",
            q=query,
            type="video",
            maxResults=max_results
        )
        response = request.execute()
        
        results = []
        for item in response["items"]:
            video_id = item["id"]["videoId"]
            
            results.append({
                "title": item["snippet"]["title"],
                "channel_title": item["snippet"]["channelTitle"],
                "thumbnail": item["snippet"]["thumbnails"]["high"]["url"],
                "video_id": video_id
            })
            
        return results
    except Exception as e:
        logging.error(f"Error searching videos with API: {str(e)}")
        return []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    query = request.form.get('query', '')
    
    if not query:
        flash('Please enter a search query or YouTube URL', 'danger')
        return redirect(url_for('index'))
    
    # Check if the query is a YouTube URL by looking for youtube.com or youtu.be
    if 'youtube.com/watch' in query or 'youtu.be/' in query:
        # Extract video ID from the URL
        video_id = None
        
        # Handle youtube.com URLs
        if 'youtube.com/watch' in query:
            import re
            match = re.search(r'(?:v=|\/)([0-9A-Za-z_-]{11})', query)
            if match:
                video_id = match.group(1)
        
        # Handle youtu.be URLs
        elif 'youtu.be/' in query:
            import re
            match = re.search(r'youtu\.be\/([0-9A-Za-z_-]{11})', query)
            if match:
                video_id = match.group(1)
        
        if video_id:
            # Redirect directly to the video detail page
            return redirect(url_for('video_detail', video_id=video_id))
        else:
            flash('Invalid YouTube URL. Could not extract video ID.', 'danger')
            return redirect(url_for('index'))
    
    # If not a YouTube URL, treat as a search query
    results = search_videos(query)
    
    if not results:
        flash('No videos found for your search query', 'warning')
        return redirect(url_for('index'))
    
    return render_template('search_results.html', results=results, query=query)

@app.route('/video/<video_id>')
def video_detail(video_id):
    video_url = f"https://www.youtube.com/watch?v={video_id}"
    
    try:
        # Get video info
        video_info = get_video_info(video_id)
        
        if not video_info:
            # Create a minimal video info object with the ID
            video_info = {
                "title": f"YouTube Video {video_id}",
                "channel_title": "YouTube Creator",
                "thumbnail": f"https://img.youtube.com/vi/{video_id}/hqdefault.jpg",
                "description": "Video information could not be retrieved. You can still try to download this video.",
                "view_count": "N/A",
                "video_id": video_id
            }
            flash('Limited video information available. Download functionality may still work.', 'warning')
        
        # Use yt-dlp to get reliable formats information
        formats = []
        is_video_downloadable = True
        
        try:
            # Use yt-dlp to get formats in JSON format
            cmd = [
                'yt-dlp', 
                '--no-playlist',
                '--dump-json',
                '--no-download',
                video_url
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0 and result.stdout:
                video_data = json.loads(result.stdout)
                
                # Extract available formats
                format_list = []
                
                # Prioritize 720p formats and other combined formats (video+audio)
                # Format 22 is the standard 720p format with audio
                # Add other common formats that include both video and audio
                for format_id in ['22', '18', '137', '136', '135', '299', '298', '397', '396']:
                    for fmt in video_data.get('formats', []):
                        if str(fmt.get('format_id')) == format_id and fmt.get('vcodec') != 'none':
                            # For formats that have both video and audio
                            if fmt.get('acodec') != 'none':
                                format_list.append({
                                    'itag': fmt.get('format_id'),
                                    'resolution': f"{fmt.get('height', 'unknown')}p",
                                    'file_size': f"{int(fmt.get('filesize', 0)) / (1024 * 1024):.1f} MB" if fmt.get('filesize') else "Size unknown",
                                    'mime_type': f"video/{fmt.get('ext', 'mp4')}"
                                })
                
                # Add any additional 720p format if not already included
                for fmt in video_data.get('formats', []):
                    if fmt.get('height') == 720 and fmt.get('vcodec') != 'none' and fmt.get('acodec') != 'none':
                        # Check if this format is already in our list
                        if not any(f.get('itag') == fmt.get('format_id') for f in format_list):
                            format_list.append({
                                'itag': fmt.get('format_id'),
                                'resolution': "720p",
                                'file_size': f"{int(fmt.get('filesize', 0)) / (1024 * 1024):.1f} MB" if fmt.get('filesize') else "Size unknown",
                                'mime_type': f"video/{fmt.get('ext', 'mp4')}"
                            })
                
                # Add audio-only format
                for fmt in video_data.get('formats', []):
                    if fmt.get('vcodec') == 'none' and fmt.get('acodec') != 'none':
                        format_list.append({
                            'itag': fmt.get('format_id'),
                            'resolution': f"Audio ({fmt.get('ext', 'mp4').upper()})",
                            'file_size': f"{int(fmt.get('filesize', 0)) / (1024 * 1024):.1f} MB" if fmt.get('filesize') else "Size unknown",
                            'mime_type': f"audio/{fmt.get('ext', 'mp4')}"
                        })
                        break  # Just add one audio format
                
                # Use the identified formats
                if format_list:
                    formats = format_list
                else:
                    # Fallback to some default formats if none were found
                    # Prioritize '22' for 720p quality
                    formats = [
                        {
                            'itag': '22',
                            'resolution': '720p',
                            'file_size': 'Size unknown',
                            'mime_type': 'video/mp4'
                        },
                        {
                            'itag': '18',
                            'resolution': '360p',
                            'file_size': 'Size unknown',
                            'mime_type': 'video/mp4'
                        },
                        {
                            'itag': '140',
                            'resolution': 'Audio only (M4A)',
                            'file_size': 'Size unknown',
                            'mime_type': 'audio/mp4'
                        }
                    ]
            else:
                # Fallback in case of yt-dlp failure
                logging.error(f"Error with yt-dlp: {result.stderr}")
                
                # Fallback to default formats
                # Prioritize '22' for 720p quality
                formats = [
                    {
                        'itag': '22',
                        'resolution': '720p',
                        'file_size': 'Size unknown',
                        'mime_type': 'video/mp4'
                    },
                    {
                        'itag': '18',
                        'resolution': '360p',
                        'file_size': 'Size unknown',
                        'mime_type': 'video/mp4'
                    },
                    {
                        'itag': '140',
                        'resolution': 'Audio only (M4A)',
                        'file_size': 'Size unknown',
                        'mime_type': 'audio/mp4'
                    }
                ]
        except Exception as e:
            logging.error(f"Error getting video formats: {str(e)}")
            flash('Unable to retrieve all available formats. Basic download options will be shown.', 'warning')
            
            # Provide some default formats for common resolutions
            # '22' is specifically 720p with audio - prioritize this for best quality
            formats = [
                {
                    'itag': '22',
                    'resolution': '720p',
                    'file_size': 'Size unknown',
                    'mime_type': 'video/mp4'
                },
                {
                    'itag': '18',
                    'resolution': '360p',
                    'file_size': 'Size unknown',
                    'mime_type': 'video/mp4'
                },
                {
                    'itag': '140',
                    'resolution': 'Audio only (M4A)',
                    'file_size': 'Size unknown',
                    'mime_type': 'audio/mp4'
                }
            ]
        
        return render_template('download.html', 
                              video=video_info, 
                              formats=formats, 
                              is_downloadable=is_video_downloadable)
    
    except Exception as e:
        logging.error(f"Error in video detail: {str(e)}")
        flash('An error occurred while processing the video. Please try another video or format.', 'danger')
        return redirect(url_for('index'))

@app.route('/download', methods=['POST'])
def download_video():
    video_id = request.form.get('video_id')
    itag = request.form.get('itag')
    
    if not video_id or not itag:
        flash('Missing video information', 'danger')
        return redirect(url_for('index'))
    
    video_url = f"https://www.youtube.com/watch?v={video_id}"
    
    try:
        # Try to get video info to determine filename
        video_title = None
        file_extension = 'mp4'  # Default extension
        mime_type = 'video/mp4'  # Default mime type
        
        # First, try to get title from get_video_info function
        try:
            video_info = get_video_info(video_id)
            if video_info and 'title' in video_info:
                video_title = video_info['title']
        except:
            pass
        
        # If no title was found, use fallback
        if not video_title:
            video_title = f"YouTube_Video_{video_id}"
        
        # Create a safe filename
        safe_title = re.sub(r'[^\w\-_]', '_', video_title)
        
        # Create temporary directory for downloading
        with tempfile.TemporaryDirectory() as temp_dir:
            output_file = os.path.join(temp_dir, f"{safe_title}.%(ext)s")
            
            # Use yt-dlp to download the video with enhanced options
            # If itag is empty or not provided, default to best available up to 720p
            cmd_base = [
                'yt-dlp',
                '--no-playlist',
                '--no-check-certificate',  # Avoid certificate errors
            ]
            
            # If itag is '22', it's the standard 720p format with audio
            # For best reliability when specifically requesting 720p, add a fallback
            if itag == '22':
                cmd = cmd_base + [
                    '-f', itag + '/bestvideo[height<=720]+bestaudio/best[height<=720]',
                    '-o', output_file,
                    video_url
                ]
            else:
                cmd = cmd_base + [
                    '-f', itag,
                    '-o', output_file,
                    video_url
                ]
            
            logging.info(f"Running yt-dlp with command: {' '.join(cmd)}")
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                logging.error(f"yt-dlp error: {result.stderr}")
                flash('An error occurred while downloading the video. Please try a different format or video.', 'danger')
                return redirect(url_for('video_detail', video_id=video_id))
            
            # Find the downloaded file
            downloaded_files = os.listdir(temp_dir)
            if not downloaded_files:
                flash('Download failed - no file was created', 'danger')
                return redirect(url_for('video_detail', video_id=video_id))
            
            downloaded_file = os.path.join(temp_dir, downloaded_files[0])
            logging.info(f"Downloaded file: {downloaded_file}")
            
            # Determine file extension and mime type from downloaded file
            _, file_extension = os.path.splitext(downloaded_file)
            file_extension = file_extension.lstrip('.')
            
            if file_extension.lower() in ['mp4', 'webm', 'mkv']:
                mime_type = f"video/{file_extension.lower()}"
            elif file_extension.lower() in ['mp3', 'm4a']:
                mime_type = f"audio/{file_extension.lower()}"
            
            # Set filename for download
            download_filename = f"{safe_title}.{file_extension}"
            
            # Send the file to the user
            return send_file(
                downloaded_file,
                as_attachment=True,
                download_name=download_filename,
                mimetype=mime_type
            )
    
    except Exception as e:
        logging.error(f"Error downloading video: {str(e)}")
        flash('An error occurred while downloading the video. Please try a different format or video.', 'danger')
    
    return redirect(url_for('video_detail', video_id=video_id))

# SEO Routes
@app.route('/robots.txt')
def robots():
    return send_file('robots.txt')

@app.route('/sitemap.xml')
def sitemap():
    return send_file('sitemap.xml')

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('index.html', error="Page not found"), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('index.html', error="Server error occurred"), 500
