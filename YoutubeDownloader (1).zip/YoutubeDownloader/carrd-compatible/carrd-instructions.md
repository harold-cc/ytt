# Harkar's YT Downloader for Carrd.co - Implementation Guide

This guide shows you how to set up the YouTube downloader on Carrd.co. Since Carrd.co doesn't support server-side processing, we'll use external services for the actual downloading functionality.

## Step 1: Set Up Your Carrd Site

1. Create a new Carrd site or use an existing one
2. Choose a dark theme or add a background image that matches your design preference

## Step 2: Add These Elements to Your Carrd Site

Add the following elements in this order:

1. A heading with the text "Harkar's YT Downloader"
2. A text element with subtitle "Download your favorite YouTube videos quickly and easily"
3. A form container with:
   - A text input field (for the YouTube URL)
   - A button labeled "Get Video"
4. A blank container (this will hold the video details)
5. A blank container for the "About This Tool" section

## Step 3: Add Custom Code

### HTML Code (Add to Embed element)

```html
<!-- Video Details Container (initially hidden) -->
<div id="videoContainer" style="display: none;">
  <div class="video-details">
    <img id="thumbnail" class="video-thumbnail" src="" alt="Video thumbnail">
    <div class="video-info">
      <h2 id="title" class="video-title"></h2>
      <p id="channel" class="video-channel"></p>
      
      <div class="download-options">
        <h3 class="download-title">Download Options</h3>
        <div class="download-buttons" id="downloadOptions"></div>
        <div class="alert">
          The download will begin in a new window. If it doesn't start automatically, check if your browser blocked the popup.
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Loading Spinner (initially hidden) -->
<div id="loadingSpinner" style="display: none;" class="spinner">
  <div class="spinner-circle"></div>
  <p>Processing your request...</p>
</div>
```

### CSS Code (Add to Site Settings > Custom CSS)

```css
/* Custom styling for the YouTube downloader */
.video-thumbnail {
  width: 100%;
  max-width: 300px;
  border-radius: 8px;
  margin-bottom: 15px;
}

.video-title {
  font-size: 1.4rem;
  margin-bottom: 5px;
}

.video-channel {
  opacity: 0.7;
  margin-bottom: 15px;
}

.download-title {
  font-size: 1.2rem;
  margin-top: 20px;
  margin-bottom: 10px;
}

.download-buttons {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-bottom: 15px;
}

.download-btn {
  display: block;
  padding: 10px 15px;
  text-align: center;
  background-color: transparent;
  border: 1px solid;
  border-radius: 5px;
  text-decoration: none;
  transition: all 0.3s ease;
}

.download-btn.mp3 {
  border-color: #28a745;
  color: #28a745;
}

.download-btn.mp3:hover {
  background-color: #28a745;
  color: white;
}

.download-btn.mp4 {
  border-color: #0d6efd;
  color: #0d6efd;
}

.download-btn.mp4:hover {
  background-color: #0d6efd;
  color: white;
}

.download-btn.more {
  border-color: #6c757d;
  color: #6c757d;
}

.download-btn.more:hover {
  background-color: #6c757d;
  color: white;
}

.alert {
  margin-top: 15px;
  padding: 10px 15px;
  background-color: rgba(13, 202, 240, 0.2);
  border: 1px solid rgba(13, 202, 240, 0.3);
  border-radius: 5px;
  color: #0dcaf0;
}

/* Loading spinner */
.spinner {
  text-align: center;
  margin: 30px 0;
}

.spinner-circle {
  display: inline-block;
  width: 40px;
  height: 40px;
  border: 4px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: #0d6efd;
  animation: spin 1s ease-in-out infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}
```

### JavaScript Code (Add to Site Settings > Custom JavaScript)

```javascript
document.addEventListener('DOMContentLoaded', function() {
  // Get references to the input field and button from your Carrd form
  // You'll need to inspect and find the correct IDs that Carrd assigns
  const videoUrlInput = document.querySelector('input[type="text"]');
  const processButton = document.querySelector('button');
  
  // Get references to our custom elements
  const loadingSpinner = document.getElementById('loadingSpinner');
  const videoContainer = document.getElementById('videoContainer');
  const thumbnail = document.getElementById('thumbnail');
  const title = document.getElementById('title');
  const channel = document.getElementById('channel');
  const downloadOptions = document.getElementById('downloadOptions');
  
  // Extract video ID from YouTube URL
  function extractVideoId(url) {
    const regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[7].length === 11) ? match[7] : null;
  }
  
  // Add click event to the button
  if (processButton) {
    processButton.addEventListener('click', function(e) {
      e.preventDefault(); // Prevent form submission
      
      const url = videoUrlInput.value.trim();
      
      if (!url) {
        alert('Please enter a YouTube URL');
        return;
      }
      
      const videoId = extractVideoId(url);
      
      if (!videoId) {
        alert('Invalid YouTube URL. Please enter a valid URL.');
        return;
      }
      
      // Show loading spinner
      loadingSpinner.style.display = 'block';
      videoContainer.style.display = 'none';
      
      // Use oEmbed API to get video info
      fetch(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`)
        .then(response => {
          if (!response.ok) {
            throw new Error('Video information unavailable');
          }
          return response.json();
        })
        .then(data => {
          // Update video details
          title.textContent = data.title;
          channel.textContent = `By: ${data.author_name}`;
          thumbnail.src = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
          
          // Create download buttons that link to external services
          downloadOptions.innerHTML = `
            <a href="https://yt5s.com/en/youtube-to-mp3?q=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D${videoId}" 
               target="_blank" class="download-btn mp3">
              Download as MP3
            </a>
            <a href="https://ytmp4.click/en/youtube-to-mp4?q=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D${videoId}" 
               target="_blank" class="download-btn mp4">
              Download as MP4 (720p)
            </a>
            <a href="https://www.y2mate.com/youtube/${videoId}" 
               target="_blank" class="download-btn more">
              More Download Options
            </a>
          `;
          
          // Hide spinner and show video details
          loadingSpinner.style.display = 'none';
          videoContainer.style.display = 'block';
        })
        .catch(error => {
          loadingSpinner.style.display = 'none';
          alert(`Error: ${error.message}`);
        });
    });
    
    // Add Enter key functionality
    videoUrlInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        processButton.click();
      }
    });
  }
});
```

## Step 4: Customize Your About Section

Create content for your "About" section using Carrd's text elements and containers:

### Features:
- Enter YouTube video URLs
- View video details
- Download videos in available formats
- Simple and easy to use interface

### Terms of Use:
- Only download videos for personal use
- This tool uses third-party services for downloading
- Some videos may be unavailable due to restrictions
- No registration required

## Step 5: Add a Footer

Add a text element at the bottom with:
```
Easy YouTube video downloads for your personal use.
© 2025 Harkar's YT Downloader
```

## Step 6: Publish Your Site

Once you've set everything up, publish your site through Carrd's interface.

## Notes About This Implementation

1. **External Services**: This implementation uses third-party services (yt5s.com, ytmp4.click, y2mate.com) for the actual downloading functionality since Carrd cannot process downloads directly.

2. **Limited Functionality**: This version is more limited than the original Python Flask app. It only supports direct URL input (not search) and relies on external services for downloading.

3. **CORS Limitations**: The YouTube oEmbed API might have CORS restrictions that could prevent it from working directly from Carrd in some cases. If this happens, you might need to display a direct link to the external services instead.

4. **Carrd Element IDs**: When implementing on Carrd, you'll need to inspect the page to find the correct IDs for the input field and button that Carrd generates.

5. **Background Image**: Upload your background image to Carrd and set it as the page background.