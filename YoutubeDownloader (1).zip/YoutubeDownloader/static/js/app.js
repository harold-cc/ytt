document.addEventListener('DOMContentLoaded', function() {
    // Handle download form submission
    const downloadForm = document.getElementById('downloadForm');
    const downloadBtn = document.getElementById('downloadBtn');
    const downloadProgress = document.getElementById('downloadProgress');
    const progressBar = downloadProgress ? downloadProgress.querySelector('.progress-bar') : null;
    
    if (downloadForm) {
        downloadForm.addEventListener('submit', function(e) {
            // Show progress bar on form submission
            if (downloadProgress && progressBar) {
                downloadBtn.disabled = true;
                downloadBtn.innerHTML = '<i class="bi bi-hourglass-split"></i> Preparing Download...';
                downloadProgress.classList.remove('d-none');
                
                // Simulate progress
                simulateProgress(progressBar);
            }
        });
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
});

function simulateProgress(progressBar) {
    // Simulate download progress
    let progress = 0;
    const interval = setInterval(function() {
        progress += Math.random() * 10;
        if (progress > 90) {
            clearInterval(interval);
            progressBar.style.width = '90%';
            progressBar.setAttribute('aria-valuenow', 90);
        } else {
            progressBar.style.width = progress + '%';
            progressBar.setAttribute('aria-valuenow', progress);
        }
    }, 500);
}
